<?php $__env->startSection('page', $page); ?>
<?php $__env->startSection('title', getSetting('APPLICATION_NAME') . ' | ' . $page); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
      <div class="row">
        <div class="col-sm-6">
          <div class="row">
            <div class="form-group">
              <span>Current version: </span>
              <label><?php echo e(getSetting('VERSION')); ?></label>
            </div>
          </div>
          <div class="row">
            <div class="form-group">
              <button id="checkForUpdate" class="btn btn-primary">Check for update</button>
              <button id="downloadUpdate" class="btn btn-success" hidden>Download</button>
            </div>
          </div>
        </div>
        <div class="col-sm-6">
          <div class="form-group">
              <div class="callout callout-info">
                <h5>Changelog</h5>

                <pre id="changelog">-</pre>
              </div>
            </div>
        </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\JupiterMeet\resources\views/admin/update.blade.php ENDPATH**/ ?>