<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\JupiterMeet\JupiterMeet_2.0.0\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>