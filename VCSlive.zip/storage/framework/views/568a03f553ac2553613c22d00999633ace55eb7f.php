<body>
	<p>Hi <?php echo e(auth::user()->username); ?>, we have received your payment! </p>

    <p>Click <a href="<?php echo e(Request::root()); ?>/profile">here</a> to check details.</p>

    <p>Thank you!</p>
</body>
<?php /**PATH C:\xampp\htdocs\JupiterMeet\resources\views/emails/confirmation.blade.php ENDPATH**/ ?>