<body>
	<p>Greetings! <?php echo e(auth()->user()->username); ?> has invited you to attend a virtual meeting.</p>

	<ul>
		<li><b>Meeting ID</b>: <?php echo e($meeting['meeting_id']); ?></li>
		<li><b>Title</b>: <?php echo e($meeting['title']); ?></li>
		<li><b>Password</b>: <?php echo e($meeting['password'] ? $meeting['password'] : '-'); ?></li>
	    <li><b>Description</b>: <?php echo e($meeting['description'] ? $meeting['description'] : '-'); ?></li>
	</ul>

    <p>Click <a href="<?php echo e(Request::root()); ?>/meeting/<?php echo e($meeting['meeting_id']); ?>">here</a> to join the meeting!</p>

    <p>Thank you!</p>
</body>
<?php /**PATH C:\xampp\htdocs\JupiterMeet\resources\views/emails/invitation.blade.php ENDPATH**/ ?>