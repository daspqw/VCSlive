<?php $__env->startSection('page', $page); ?>
<?php $__env->startSection('title', getSetting('APPLICATION_NAME') . ' | ' . $page); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
      <div class="row">
        <div class="col-sm-6">
          <div class="row">
              <div class="col-sm-12">
                  URL: <a href="<?php echo e($url); ?>" target="_blank"><?php echo e($url); ?></a>
              </div>
          </div>
          <div class="row">
              <div class="col-sm-12">
                  Status: <span id="status" class="badge p-1">-</span> 
              </div>
          </div>
          <div class="row">
              <div class="col-sm-12">
                  <button id="checkSignaling" class="btn btn-info mt-2">Refresh</button>
              </div>
          </div>
        </div>
        <div class="col-sm-6">
          <h4>Troubleshooting</h4>
          <div class="callout callout-info">
            <ul>
              <li>Make sure, the URL is correct</li>
              <li>Make sure, the /server/.env file has been updated as per the documentation</li>
              <li>Make sure, the NodeJS service is started as per the documentation</li>
              <li>Make sure, the required ports are allowed in the Firewall as per the documentation</li>
              <li>Make sure, the SSL certificates are valid</li>
              <li>If you are using Cloudflare, make sure you use 8443 port</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">
  $("#checkSignaling").trigger('click');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\JupiterMeet\resources\views/admin/signaling.blade.php ENDPATH**/ ?>