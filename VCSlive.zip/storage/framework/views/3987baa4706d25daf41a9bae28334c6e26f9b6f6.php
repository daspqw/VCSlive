<?php $__env->startSection('page', $page); ?>
<?php $__env->startSection('title', getSetting('APPLICATION_NAME') . ' | ' . $page); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
      <form id="changePasswordEdit">
        <div class="row">
          <div class="col-sm-6">
            <div class="form-group">
              <label>Current password</label>
              <input type="password" name="current" class="form-control" placeholder="Enter Current Password" maxlength="50" required>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-6">
            <div class="form-group">
              <label>New password</label>
              <input type="password" name="new" class="form-control" placeholder="Enter New Password" maxlength="50" required>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-6">
            <div class="form-group">
              <label>Confirm password</label>
              <input type="password" name="confirm" class="form-control" placeholder="Confirm New Password" maxlength="50" required>
            </div>
          </div>
        </div>

        <button type="submit" id="save" class="btn btn-primary">Save</button>
      </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  <script type="text/javascript">
    $("#changePasswordEdit").on('submit', function (e) {
      e.preventDefault();

      $("#save").attr('disabled', true);

      $.ajax({
        headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          },
          url: 'update-password',
          data: $(this).serialize(),
          type: 'post',
      }).done(function(data) {
        data = JSON.parse(data);
        $("#save").attr('disabled', false);

        if (data.success) {
          showSuccess('Data updated successfully');
          $("#changePasswordEdit")[0].reset();
        } else {
          showError();
        }
      }).catch(function () {
        showError();
        $("#save").attr('disabled', false);
      });
    });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\JupiterMeet\resources\views/admin/change-password/index.blade.php ENDPATH**/ ?>