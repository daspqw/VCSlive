<body>
	<p>Hi <?php echo e($username); ?>, your plan has expired! </p>

    <p>Click <a href="<?php echo e(Request::root()); ?>/pricing">here</a> to renew now.</p>

    <p>Thank you!</p>
</body>
<?php /**PATH C:\xampp\htdocs\JupiterMeet\resources\views/emails/plan.blade.php ENDPATH**/ ?>